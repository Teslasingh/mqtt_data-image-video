import paho.mqtt.client as mqtt

import base64

client=mqtt.Client()

client.connect('tesla001.ddns.net', 1820, 60)

client.subscribe("topic")

with open("panda.jpeg","rb") as image:

    img= image.read()

message= img

base64_bytes = base64.b64encode(message)

base64_message = base64_bytes.decode('ascii')
#print(base64_message)

client.publish('topic', base64_message)

