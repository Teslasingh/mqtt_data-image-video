import paho.mqtt.client as mqtt
import base64

client=mqtt.Client()
client.connect('tesla001.ddns.net', 1820, 60)

client.subscribe('topic')

def on_message(client,userdata, message):
    msg=str(message.payload.decode('utf-8'))
    print(msg)

    img = msg.encode("ascii")
    final_msg = base64.b64decode(img)
    open('recive_img.jpeg', 'wb').write(final_msg)

client.on_message=on_message
client.loop_forever()
