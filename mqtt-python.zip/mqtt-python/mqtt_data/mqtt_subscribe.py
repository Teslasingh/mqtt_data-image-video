import paho.mqtt.client as mqtt
import time
#import cv2

def on_message(client, userdata, message):
    print("Received message: ", str(message.payload.decode("utf-8")))

mqttBroker = "tesla001.ddns.net"
client = mqtt.Client("sub-client")
client.connect(mqttBroker, 1820, 60)

client.loop_start()
while True:
    client.subscribe("TEMPERATURE")
    client.on_message = on_message
    time.sleep(0.05)

client.loop_end()
