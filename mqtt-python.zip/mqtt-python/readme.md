Playing around with Python MQTT client Paho-MQTT and Mosquitto MQTT broker.
You find a detailed explanation of the code and MQTT basics on medium: https://medium.com/@codeanddogs/mqtt-basics-with-python-examples-7c758e605d4
